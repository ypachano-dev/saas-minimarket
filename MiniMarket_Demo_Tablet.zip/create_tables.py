print("🤖 ¡Sí estoy leyendo el archivo!")
from app.db.session import engine
from app.models.base import Base

# Es CRUCIAL importar todos los modelos explícitamente aquí.
# Si no se importan, SQLAlchemy no sabrá que existen al momento de ejecutar create_all.
from app.models.empresa import Empresa
from app.models.usuario import Usuario
from app.models.cliente import Cliente
from app.models.producto import Producto
from app.models.ticket import Ticket
from app.models.lote import Lote
from app.models.merma import Merma
from app.models.tasa import TasaCambio
from app.models.peticion_faltante import PeticionFaltante
from app.models.seguimiento_bot import SeguimientoBot
from app.models.proveedor import Proveedor
from app.models.vehiculo import Vehiculo
from app.models.pedido_delivery import PedidoDelivery
from app.models.orden_compra import OrdenCompra, OrdenCompraItem

def crear_estructura_SaaS():
    print("🚀 Conectando con MySQL e iniciando creación de tablas...")
    try:
        # Lee la Metadata de Base y crea las tablas físicas en el orden relacional correcto
        Base.metadata.create_all(bind=engine)
        print("✅ ¡Espectacular! Las 13 tablas se crearon con éxito en tu base de datos local.")
        print("📋 Tablas listas: Empresa, Usuario, Cliente, Producto, Ticket, Lote, Merma, TasaCambio, PeticionFaltante, SeguimientoBot, Proveedor, Vehiculo, PedidoDelivery, OrdenCompra.")
    except Exception as e:
        print(f"❌ Error fatal al intentar mapear las tablas: {e}")
        print("\n💡 Guía de supervivencia rápido:")
        print("1. Certifica que tu servidor local (XAMPP, WampServer o MySQL directo) esté encendido.")
        print("2. Verifica que la base de datos especificada en tu archivo '.env' o 'config.py' ya exista físicamente (creada en phpMyAdmin o DBeaver).")

if __name__ == "__main__":
    crear_estructura_SaaS()