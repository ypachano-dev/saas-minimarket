import datetime
import os
from decimal import Decimal
from app.core.security import generar_hash_password, verificar_password, crear_access_token, get_current_user, verificar_rol
from fastapi import FastAPI, Depends, HTTPException, status, File, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from sqlalchemy import func, and_
from sqlalchemy.orm import Session
from typing import Generator, List, Optional

# Importamos la conexión a la base de datos
from app.db.session import SessionLocal
from app.core.config import settings

# Importamos los modelos físicos y el molde de validación
from app.models.empresa import Empresa
from app.models.usuario import Usuario
from app.models.producto import Producto
from app.models.lote import Lote
from app.models.merma import Merma
from app.models.ticket import Ticket
from app.models.cliente import Cliente
from app.models.tasa import TasaCambio
from app.models.peticion_faltante import PeticionFaltante
from app.models.seguimiento_bot import SeguimientoBot
from app.models.proveedor import Proveedor
from app.models.vehiculo import Vehiculo
from app.models.pedido_delivery import PedidoDelivery
from app.models.orden_compra import OrdenCompra, OrdenCompraItem
from app.schemas import (
    RegistroEmpresaAdmin, LoginRequest, Token, TokenData,
    ClienteCreate, ClienteUpdate, ClienteResponse,
    ProductoCreate, ProductoResponse, LoteCreate, LoteResponse,
    MermaCreate, MermaResponse, TicketCreate, TicketResponse, VentaResponse,
    TasaCambioUpdate, TasaCambioResponse,
    StockBajoItem, LoteCriticoItem, VentasHoyResponse, ResumenMermasResponse, DashboardResponse,
    PeticionFaltanteCreate, PeticionFaltanteResponse, SeguimientoBotResponse,
    SeguimientoBotCreate, SeguimientoBotUpdate,
    ProveedorCreate, ProveedorResponse, VehiculoCreate, VehiculoResponse,
    UsuarioCreate, UsuarioResponse, TicketPesajeCreate, ProcesarPagoTickets,
    PedidoDeliveryCreate, PedidoDeliveryResponse, OrdenCompraCreate, OrdenCompraResponse
)

# Grupos de roles para el control de accesos (RBAC)
# Gestión: inventario, compras, mermas, tasa de cambio y analítica del negocio
ROLES_GESTION = ["admin", "propietario"]
# Operación de caja: ventas, clientes y consulta de productos para el escáner
ROLES_OPERACION = ["cajero", "admin", "propietario"]

app = FastAPI(
    title=settings.PROJECT_NAME,
    version="1.0.0",
    docs_url="/docs",
    redoc_url=None
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:5173"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Función puente para abrir y cerrar la base de datos automáticamente
def get_db() -> Generator:
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

# 1. Ruta de Sanity Check (movida fuera de "/" para dejar esa ruta libre al frontend)
@app.get("/api/v1/status", tags=["Sanity Check"])
def read_root():
    return {
        "status": "online",
        "sistema": settings.PROJECT_NAME,
        "api_version": "1.0.0",
        "ambiente": "desarrollo_local"
    }

# 2. Registrar Empresa y Administrador en sincronía con tus modelos reales
@app.post("/api/v1/auth/registrar-saas", tags=["Autenticación SaaS"], status_code=status.HTTP_201_CREATED)
def registrar_empresa_y_admin(datos: RegistroEmpresaAdmin, db: Session = Depends(get_db)):

    # Validación: bcrypt soporta como máximo 72 bytes en la contraseña
    if len(datos.password_admin.encode("utf-8")) > 72:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="La contraseña no puede exceder los 72 caracteres."
        )

    # Validación: Verificar si el RIF de la empresa ya existe
    empresa_existente = db.query(Empresa).filter(Empresa.rif == datos.rif_or_cedula).first()
    if empresa_existente:
        raise HTTPException(status_code=400, detail="Esta empresa o RIF ya se encuentra registrada.")
        
    # Validación: Verificar si el correo del administrador ya existe
    email_existente = db.query(Usuario).filter(Usuario.email == datos.email_admin).first()
    if email_existente:
        raise HTTPException(status_code=400, detail="El correo electrónico ya está en uso por otro usuario.")

    try:
        # A. Crear la Empresa (Sincronizado con empresa.py)
        nueva_empresa = Empresa(
            nombre_comercial=datos.nombre_empresa,
            rif=datos.rif_or_cedula,
            telefono=datos.telefono,
            direccion=datos.direccion,
            status="activo"
        )
        db.add(nueva_empresa)
        db.flush() # Genera el ID temporal de la empresa

        # B. Crear el Usuario Dueño (Sincronizado con usuario.py)
        nuevo_usuario = Usuario(
            empresa_id=nueva_empresa.id,
            nombre=datos.nombre_admin,             # Ajustado a tu columna 'nombre'
            email=datos.email_admin,
            password_hash=generar_hash_password(datos.password_admin[:72]),   # ¡AHORA SÍ, ENCRIPTADO SEGURO!
            rol="propietario",  # Dueño del negocio: acceso total bajo el esquema RBAC (admin/propietario)
            status=True                           # Ajustado a tu columna 'status' tipo Boolean
        )
        db.add(nuevo_usuario)
        
        # C. Guardar definitivo en el archivo .db
        db.commit()
        db.refresh(nueva_empresa)
        db.refresh(nuevo_usuario)
        
        return {
            "mensaje": "¡SaaS configurado con éxito!",
            "empresa_creada": {
                "id": nueva_empresa.id,
                "nombre": nueva_empresa.nombre_comercial,
                "rif": nueva_empresa.rif
            },
            "administrador_creado": {
                "id": nuevo_usuario.id,
                "nombre": nuevo_usuario.nombre,
                "correo": nuevo_usuario.email,
                "rol": nuevo_usuario.rol
            }
        }
        
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail=f"Error interno al procesar el registro: {str(e)}")

# 3. Login: valida credenciales y devuelve un Token JWT con empresa_id y rol
@app.post("/api/v1/auth/login", tags=["Autenticación SaaS"], response_model=Token)
def login(datos: LoginRequest, db: Session = Depends(get_db)):

    usuario = db.query(Usuario).filter(Usuario.email == datos.email).first()

    # bcrypt soporta como máximo 72 bytes; truncamos igual que al registrar
    if not usuario or not verificar_password(datos.password[:72], usuario.password_hash):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Correo o contraseña incorrectos."
        )

    if not usuario.status:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Este usuario se encuentra inactivo. Contacte al administrador."
        )

    # El token incluye eid (empresa_id) y rol para mantener el aislamiento Multi-Tenant.
    # Se usa la clave corta 'eid' para reducir el tamaño del string JWT que viaja por la red.
    access_token = crear_access_token(
        data={
            "sub": str(usuario.id),
            "eid": usuario.empresa_id,
            "rol": usuario.rol
        }
    )

    return Token(access_token=access_token, token_type="bearer")

# 4. Crear Cliente: la empresa_id se inyecta desde el token; la cédula/RIF no puede
#    repetirse dentro de la misma empresa
@app.post("/api/v1/clientes", tags=["Clientes"], response_model=ClienteResponse, status_code=status.HTTP_201_CREATED)
def crear_cliente(
    datos: ClienteCreate,
    db: Session = Depends(get_db),
    usuario_actual: TokenData = Depends(verificar_rol(ROLES_OPERACION))
):
    duplicado = db.query(Cliente).filter(
        Cliente.empresa_id == usuario_actual.eid,
        Cliente.cedula == datos.cedula
    ).first()
    if duplicado:
        raise HTTPException(status_code=400, detail="Ya existe un cliente con esa cédula/RIF en su empresa.")

    nuevo_cliente = Cliente(
        empresa_id=usuario_actual.eid,
        **datos.model_dump()
    )

    try:
        db.add(nuevo_cliente)
        db.commit()
        db.refresh(nuevo_cliente)
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=400, detail=f"Error al registrar el cliente: {str(e)}")

    return nuevo_cliente

# 5. Listar/Buscar Clientes: filtrado obligatorio por empresa_id del token (aislamiento Multi-Tenant).
#    Acepta 'cedula' (coincidencia exacta) y/o 'q' (búsqueda parcial por nombre o cédula).
@app.get("/api/v1/clientes", tags=["Clientes"], response_model=List[ClienteResponse])
def listar_clientes(
    q: Optional[str] = None,
    cedula: Optional[str] = None,
    skip: int = 0,
    limit: int = 100,
    db: Session = Depends(get_db),
    usuario_actual: TokenData = Depends(verificar_rol(ROLES_OPERACION))
):
    query = db.query(Cliente).filter(Cliente.empresa_id == usuario_actual.eid)

    if cedula:
        query = query.filter(Cliente.cedula == cedula)

    if q:
        termino = f"%{q}%"
        query = query.filter(
            (Cliente.nombre.ilike(termino)) | (Cliente.cedula.ilike(termino))
        )

    return query.offset(skip).limit(limit).all()

# 6. Editar Cliente: primero se confirma que el cliente pertenezca a la empresa del token
#    (si no, 404); si se cambia la cédula/RIF, se valida que no choque con otro cliente
@app.put("/api/v1/clientes/{cliente_id}", tags=["Clientes"], response_model=ClienteResponse)
def actualizar_cliente(
    cliente_id: int,
    datos: ClienteUpdate,
    db: Session = Depends(get_db),
    usuario_actual: TokenData = Depends(verificar_rol(ROLES_OPERACION))
):
    cliente = db.query(Cliente).filter(
        Cliente.id == cliente_id,
        Cliente.empresa_id == usuario_actual.eid
    ).first()
    if not cliente:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="El cliente indicado no existe o no pertenece a su empresa."
        )

    datos_actualizados = datos.model_dump(exclude_unset=True)

    nueva_cedula = datos_actualizados.get("cedula")
    if nueva_cedula and nueva_cedula != cliente.cedula:
        duplicado = db.query(Cliente).filter(
            Cliente.empresa_id == usuario_actual.eid,
            Cliente.cedula == nueva_cedula,
            Cliente.id != cliente_id
        ).first()
        if duplicado:
            raise HTTPException(status_code=400, detail="Ya existe otro cliente con esa cédula/RIF en su empresa.")

    for campo, valor in datos_actualizados.items():
        setattr(cliente, campo, valor)

    try:
        db.commit()
        db.refresh(cliente)
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=400, detail=f"Error al actualizar el cliente: {str(e)}")

    return cliente

# 7. Crear Producto: la empresa_id se inyecta desde el token, nunca desde el body
@app.post("/api/v1/productos", tags=["Productos"], response_model=ProductoResponse, status_code=status.HTTP_201_CREATED)
def crear_producto(
    datos: ProductoCreate,
    db: Session = Depends(get_db),
    usuario_actual: TokenData = Depends(verificar_rol(ROLES_GESTION))
):
    nuevo_producto = Producto(
        empresa_id=usuario_actual.eid,
        **datos.model_dump()
    )

    try:
        db.add(nuevo_producto)
        db.commit()
        db.refresh(nuevo_producto)
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=400, detail=f"Error al crear el producto: {str(e)}")

    return nuevo_producto

# 8. Listar Productos: filtrado obligatorio por empresa_id del token (aislamiento Multi-Tenant)
@app.get("/api/v1/productos", tags=["Productos"], response_model=List[ProductoResponse])
def listar_productos(
    q: Optional[str] = None,
    skip: int = 0,
    limit: int = 100,
    db: Session = Depends(get_db),
    usuario_actual: TokenData = Depends(verificar_rol(ROLES_OPERACION))
):
    stock_subq = (
        db.query(Lote.producto_id, func.coalesce(func.sum(Lote.cantidad_actual), 0).label("stock_total"))
        .filter(Lote.empresa_id == usuario_actual.eid, Lote.status == "activo")
        .group_by(Lote.producto_id)
        .subquery()
    )

    query = (
        db.query(Producto, func.coalesce(stock_subq.c.stock_total, 0))
        .outerjoin(stock_subq, stock_subq.c.producto_id == Producto.id)
        .filter(Producto.empresa_id == usuario_actual.eid)
    )

    if q:
        termino = f"%{q}%"
        query = query.filter(
            (Producto.nombre.ilike(termino)) | (Producto.codigo_interno.ilike(termino))
        )

    rows = query.offset(skip).limit(limit).all()

    resultado = []
    for producto, stock_total in rows:
        item = ProductoResponse.model_validate(producto)
        item.stock_total = float(stock_total)
        resultado.append(item)
    return resultado

# 9. Registrar entrada de Lote: la empresa_id se inyecta desde el token y el producto
#    debe pertenecer a esa misma empresa
@app.post("/api/v1/lotes", tags=["Lotes"], response_model=LoteResponse, status_code=status.HTTP_201_CREATED)
def crear_lote(
    datos: LoteCreate,
    db: Session = Depends(get_db),
    usuario_actual: TokenData = Depends(verificar_rol(ROLES_GESTION))
):
    # Validación Multi-Tenant: el producto debe existir y pertenecer a la empresa del usuario
    producto = db.query(Producto).filter(
        Producto.id == datos.producto_id,
        Producto.empresa_id == usuario_actual.eid
    ).first()
    if not producto:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="El producto indicado no existe o no pertenece a su empresa."
        )

    nuevo_lote = Lote(
        empresa_id=usuario_actual.eid,
        producto_id=datos.producto_id,
        codigo_lote=datos.codigo_lote,
        cantidad_inicial=datos.cantidad_inicial,
        cantidad_actual=datos.cantidad_inicial,  # Al ingresar, lo actual inicia igual a lo inicial
        fecha_ingreso=datos.fecha_ingreso or datetime.date.today(),
        fecha_vencimiento=datos.fecha_vencimiento
    )

    try:
        db.add(nuevo_lote)
        db.commit()
        db.refresh(nuevo_lote)
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=400, detail=f"Error al registrar el lote: {str(e)}")

    return nuevo_lote

# 10. Listar Lotes activos: filtrado obligatorio por empresa_id del token (aislamiento Multi-Tenant)
@app.get("/api/v1/lotes", tags=["Lotes"], response_model=List[LoteResponse])
def listar_lotes(
    db: Session = Depends(get_db),
    usuario_actual: TokenData = Depends(get_current_user)
):
    return db.query(Lote).filter(
        Lote.empresa_id == usuario_actual.eid,
        Lote.status == "activo"
    ).all()

# 11. Registrar Merma: la empresa_id y usuario_id se inyectan desde el token, el lote
#    debe pertenecer a esa misma empresa y se descuenta de su cantidad_actual
@app.post("/api/v1/mermas", tags=["Mermas"], response_model=MermaResponse, status_code=status.HTTP_201_CREATED)
def crear_merma(
    datos: MermaCreate,
    db: Session = Depends(get_db),
    usuario_actual: TokenData = Depends(verificar_rol(ROLES_GESTION))
):
    # Validación Multi-Tenant: el lote debe existir y pertenecer a la empresa del usuario
    lote = db.query(Lote).filter(
        Lote.id == datos.lote_id,
        Lote.empresa_id == usuario_actual.eid
    ).first()
    if not lote:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="El lote indicado no existe o no pertenece a su empresa."
        )

    if datos.cantidad <= 0:
        raise HTTPException(status_code=400, detail="La cantidad de la merma debe ser mayor a cero.")

    if datos.cantidad > lote.cantidad_actual:
        raise HTTPException(
            status_code=400,
            detail="La cantidad de la merma no puede ser mayor a la cantidad actual del lote."
        )

    nueva_merma = Merma(
        empresa_id=usuario_actual.eid,
        usuario_id=usuario_actual.usuario_id,
        producto_id=lote.producto_id,
        lote_id=lote.id,
        cantidad=datos.cantidad,
        motivo=datos.motivo,
        observaciones=datos.observaciones
    )

    # Descontamos la cantidad mermada del lote de origen
    lote.cantidad_actual -= datos.cantidad

    try:
        db.add(nueva_merma)
        db.commit()
        db.refresh(nueva_merma)
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=400, detail=f"Error al registrar la merma: {str(e)}")

    return nueva_merma

# 12. Listar Mermas: filtrado obligatorio por empresa_id del token (aislamiento Multi-Tenant)
@app.get("/api/v1/mermas", tags=["Mermas"], response_model=List[MermaResponse])
def listar_mermas(
    db: Session = Depends(get_db),
    usuario_actual: TokenData = Depends(verificar_rol(ROLES_GESTION))
):
    return db.query(Merma).filter(Merma.empresa_id == usuario_actual.eid).all()

# 13. Actualizar la tasa BCV de la empresa (Bolívares por Dólar). Si no existe, se crea.
@app.put("/api/v1/tasa", tags=["Tasa de Cambio"], response_model=TasaCambioResponse)
def actualizar_tasa(
    datos: TasaCambioUpdate,
    db: Session = Depends(get_db),
    usuario_actual: TokenData = Depends(verificar_rol(ROLES_GESTION))
):
    if datos.valor_bcv <= 0:
        raise HTTPException(status_code=400, detail="El valor de la tasa BCV debe ser mayor a cero.")

    tasa = db.query(TasaCambio).filter(TasaCambio.empresa_id == usuario_actual.eid).first()
    ahora = datetime.datetime.now(datetime.timezone.utc)

    if tasa:
        tasa.valor_bcv = datos.valor_bcv
        tasa.fecha_actualizacion = ahora
    else:
        tasa = TasaCambio(
            empresa_id=usuario_actual.eid,
            valor_bcv=datos.valor_bcv,
            fecha_actualizacion=ahora
        )
        db.add(tasa)

    try:
        db.commit()
        db.refresh(tasa)
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=400, detail=f"Error al actualizar la tasa de cambio: {str(e)}")

    return tasa

# 13b. Obtener la tasa BCV de la empresa (se actualiza automáticamente si es vieja)
@app.get("/api/v1/tasa", tags=["Tasa de Cambio"], response_model=TasaCambioResponse)
def obtener_tasa(
    db: Session = Depends(get_db),
    usuario_actual: TokenData = Depends(get_current_user)
):
    tasa = db.query(TasaCambio).filter(TasaCambio.empresa_id == usuario_actual.eid).first()
    ahora = datetime.datetime.now(datetime.timezone.utc)
    
    actualizar = False
    if not tasa:
        actualizar = True
    elif tasa.fecha_actualizacion:
        fecha_act = tasa.fecha_actualizacion
        if fecha_act.tzinfo is None:
            fecha_act = fecha_act.replace(tzinfo=datetime.timezone.utc)
        if (ahora - fecha_act).total_seconds() > 4 * 3600:
            actualizar = True

    if actualizar:
        valor = Decimal("602.33")
        try:
            import urllib.request, json
            req = urllib.request.Request('https://ve.dolarapi.com/v1/dolares/oficial', headers={'User-Agent': 'Mozilla/5.0'})
            res_data = json.loads(urllib.request.urlopen(req, timeout=3).read().decode('utf-8'))
            promedio = res_data.get("promedio")
            if promedio:
                valor = Decimal(str(round(promedio, 2)))
        except Exception:
            if tasa:
                valor = tasa.valor_bcv
        
        if not tasa:
            tasa = TasaCambio(empresa_id=usuario_actual.eid, valor_bcv=valor)
            db.add(tasa)
        else:
            tasa.valor_bcv = valor
            tasa.fecha_actualizacion = ahora
        try:
            db.commit()
            db.refresh(tasa)
        except Exception:
            db.rollback()
            
    return tasa

# 14. Registrar Venta (Ticket): la empresa_id y usuario_id se inyectan desde el token.
#     Por cada producto se valida el stock disponible (suma de lotes activos) y se
#     descuenta aplicando FEFO/FIFO: primero los lotes que vencen antes / ingresaron primero.
@app.post("/api/v1/tickets", tags=["Ventas"], response_model=VentaResponse, status_code=status.HTTP_201_CREATED)
def crear_ticket(
    datos: TicketCreate,
    db: Session = Depends(get_db),
    usuario_actual: TokenData = Depends(verificar_rol(ROLES_OPERACION))
):
    if not datos.items:
        raise HTTPException(status_code=400, detail="La venta debe incluir al menos un producto.")

    # Validación Multi-Tenant: el cliente debe pertenecer a la empresa del usuario
    cliente = db.query(Cliente).filter(
        Cliente.id == datos.cliente_id,
        Cliente.empresa_id == usuario_actual.eid
    ).first()
    if not cliente:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="El cliente indicado no existe o no pertenece a su empresa."
        )

    # La tasa BCV de la empresa es obligatoria para calcular los montos en Bolívares
    tasa = db.query(TasaCambio).filter(TasaCambio.empresa_id == usuario_actual.eid).first()
    if not tasa:
        raise HTTPException(
            status_code=400,
            detail="Debe configurar la tasa de cambio BCV de su empresa (PUT /api/v1/tasa) antes de registrar ventas."
        )
    tasa_bcv = tasa.valor_bcv

    tickets_creados: list[tuple[Ticket, Decimal]] = []
    total_usd = Decimal("0.00")
    total_ves = Decimal("0.00")

    try:
        for item in datos.items:
            if item.peso <= 0:
                raise HTTPException(status_code=400, detail="La cantidad/peso de cada producto debe ser mayor a cero.")

            # Validación Multi-Tenant: el producto debe pertenecer a la empresa del usuario
            producto = db.query(Producto).filter(
                Producto.id == item.producto_id,
                Producto.empresa_id == usuario_actual.eid
            ).first()
            if not producto:
                raise HTTPException(
                    status_code=status.HTTP_404_NOT_FOUND,
                    detail=f"El producto {item.producto_id} no existe o no pertenece a su empresa."
                )

            # Lotes activos con stock, ordenados FEFO (vencen primero) y FIFO (ingresaron primero)
            lotes = db.query(Lote).filter(
                Lote.empresa_id == usuario_actual.eid,
                Lote.producto_id == item.producto_id,
                Lote.status == "activo",
                Lote.cantidad_actual > 0
            ).order_by(Lote.fecha_vencimiento.asc(), Lote.fecha_ingreso.asc()).all()

            stock_disponible = sum((lote.cantidad_actual for lote in lotes), Decimal("0"))
            if stock_disponible < item.peso:
                raise HTTPException(
                    status_code=400,
                    detail=f"Stock insuficiente para '{producto.nombre}'. Disponible: {stock_disponible}, solicitado: {item.peso}"
                )

            # Descuento FIFO/FEFO: se va consumiendo lote por lote hasta cubrir lo vendido
            restante = item.peso
            for lote in lotes:
                if restante <= 0:
                    break
                descuento = min(lote.cantidad_actual, restante)
                lote.cantidad_actual -= descuento
                restante -= descuento
                if lote.cantidad_actual == 0:
                    lote.status = "agotado"

            monto_usd = (item.peso * producto.precio_1_detalle).quantize(Decimal("0.01"))
            monto_ves = (monto_usd * tasa_bcv).quantize(Decimal("0.01"))

            nuevo_ticket = Ticket(
                empresa_id=usuario_actual.eid,
                usuario_id=usuario_actual.usuario_id,
                producto_id=item.producto_id,
                cliente_id=datos.cliente_id,
                peso=item.peso,
                monto_usd=monto_usd,
                status="procesado"
            )
            db.add(nuevo_ticket)
            tickets_creados.append((nuevo_ticket, monto_ves))
            total_usd += monto_usd
            total_ves += monto_ves

        db.commit()
        for ticket, _ in tickets_creados:
            db.refresh(ticket)

    except HTTPException:
        db.rollback()
        raise
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=400, detail=f"Error al registrar la venta: {str(e)}")

    tickets_respuesta = [
        TicketResponse(
            id=ticket.id,
            empresa_id=ticket.empresa_id,
            usuario_id=ticket.usuario_id,
            producto_id=ticket.producto_id,
            cliente_id=ticket.cliente_id,
            peso=ticket.peso,
            monto_usd=ticket.monto_usd,
            monto_ves=monto_ves,
            status=ticket.status,
            created_at=ticket.created_at,
            direccion_entrega=ticket.direccion_entrega,
            repartidor_id=ticket.repartidor_id,
            x=ticket.coord_x,
            y=ticket.coord_y,
            cliente=cliente.nombre if cliente else "Desconocido",
            direccion=ticket.direccion_entrega
        )
        for ticket, monto_ves in tickets_creados
    ]

    return VentaResponse(
        tickets=tickets_respuesta,
        total_usd=total_usd,
        total_ves=total_ves,
        tasa_bcv=tasa_bcv
    )

# 15. Listar Tickets/Ventas: filtrado obligatorio por empresa_id del token y opcionalmente
#     por 'status' y 'cliente_id'
@app.get("/api/v1/tickets", tags=["Ventas"], response_model=List[TicketResponse])
def listar_tickets(
    status: Optional[str] = None,
    cliente_id: Optional[int] = None,
    db: Session = Depends(get_db),
    usuario_actual: TokenData = Depends(verificar_rol(ROLES_OPERACION))
):
    query = db.query(Ticket).filter(Ticket.empresa_id == usuario_actual.eid)
    if status:
        query = query.filter(Ticket.status == status)
    if cliente_id:
        query = query.filter(Ticket.cliente_id == cliente_id)

    tasa = db.query(TasaCambio).filter(TasaCambio.empresa_id == usuario_actual.eid).first()
    tasa_bcv = tasa.valor_bcv if tasa else Decimal("0")

    tickets = query.all()
    resultado = []
    for ticket in tickets:
        cliente_db = db.query(Cliente).filter(Cliente.id == ticket.cliente_id).first()
        cliente_nombre = cliente_db.nombre if cliente_db else "Desconocido"
        resultado.append(
            TicketResponse(
                id=ticket.id,
                empresa_id=ticket.empresa_id,
                usuario_id=ticket.usuario_id,
                producto_id=ticket.producto_id,
                cliente_id=ticket.cliente_id,
                peso=ticket.peso,
                monto_usd=ticket.monto_usd,
                monto_ves=(ticket.monto_usd * tasa_bcv).quantize(Decimal("0.01")),
                status=ticket.status,
                created_at=ticket.created_at,
                direccion_entrega=ticket.direccion_entrega,
                repartidor_id=ticket.repartidor_id,
                x=ticket.coord_x,
                y=ticket.coord_y,
                cliente=cliente_nombre,
                direccion=ticket.direccion_entrega
            )
        )
    return resultado

# 16. Dashboard de Reportes: KPIs operativos del día filtrados estrictamente por la
#     empresa del token (ventas de hoy, stock bajo, vencimientos próximos y mermas del mes)
@app.get("/api/v1/reportes/dashboard", tags=["Reportes"], response_model=DashboardResponse)
def obtener_dashboard(
    db: Session = Depends(get_db),
    usuario_actual: TokenData = Depends(verificar_rol(ROLES_GESTION))
):
    empresa_id = usuario_actual.eid
    hoy = datetime.date.today()

    # Tasa BCV activa de la empresa (0 si aún no se ha configurado)
    tasa = db.query(TasaCambio).filter(TasaCambio.empresa_id == empresa_id).first()
    tasa_bcv = tasa.valor_bcv if tasa else Decimal("0")

    # --- Ventas del Día: suma de monto_usd de los tickets procesados hoy ---
    ventas_usd = db.query(
        func.coalesce(func.sum(Ticket.monto_usd), 0)
    ).filter(
        Ticket.empresa_id == empresa_id,
        Ticket.status == "procesado",
        func.date(Ticket.created_at) == hoy
    ).scalar()
    ventas_usd = Decimal(str(ventas_usd))
    ventas_ves = (ventas_usd * tasa_bcv).quantize(Decimal("0.01"))

    # --- Alertas de Stock Bajo: stock total (suma de lotes activos) <= 10 unidades ---
    stock_bajo_rows = (
        db.query(
            Producto.id,
            Producto.codigo_interno,
            Producto.nombre,
            func.coalesce(func.sum(Lote.cantidad_actual), 0).label("stock_total")
        )
        .outerjoin(
            Lote,
            and_(
                Lote.producto_id == Producto.id,
                Lote.empresa_id == empresa_id,
                Lote.status == "activo"
            )
        )
        .filter(Producto.empresa_id == empresa_id, Producto.status == True)
        .group_by(Producto.id, Producto.codigo_interno, Producto.nombre)
        .having(func.coalesce(func.sum(Lote.cantidad_actual), 0) <= 10)
        .all()
    )
    alertas_stock_bajo = [
        StockBajoItem(
            producto_id=row.id,
            codigo_interno=row.codigo_interno,
            nombre=row.nombre,
            stock_total=Decimal(str(row.stock_total))
        )
        for row in stock_bajo_rows
    ]

    # --- Alertas de Vencimiento Crítico: lotes activos que vencen en menos de 30 días ---
    limite_vencimiento = hoy + datetime.timedelta(days=30)
    lotes_criticos = (
        db.query(Lote, Producto.nombre)
        .join(Producto, Producto.id == Lote.producto_id)
        .filter(
            Lote.empresa_id == empresa_id,
            Lote.status == "activo",
            Lote.fecha_vencimiento <= limite_vencimiento
        )
        .order_by(Lote.fecha_vencimiento.asc())
        .all()
    )
    alertas_vencimiento = [
        LoteCriticoItem(
            lote_id=lote.id,
            producto_id=lote.producto_id,
            producto_nombre=producto_nombre,
            codigo_lote=lote.codigo_lote,
            cantidad_actual=lote.cantidad_actual,
            fecha_vencimiento=lote.fecha_vencimiento,
            dias_restantes=(lote.fecha_vencimiento - hoy).days
        )
        for lote, producto_nombre in lotes_criticos
    ]

    # --- Resumen de Mermas del Mes en curso: total mermado, registros y motivo más frecuente ---
    primer_dia_mes = datetime.datetime.combine(hoy.replace(day=1), datetime.time.min)
    total_mermado, total_registros = db.query(
        func.coalesce(func.sum(Merma.cantidad), 0),
        func.count(Merma.id)
    ).filter(
        Merma.empresa_id == empresa_id,
        Merma.created_at >= primer_dia_mes
    ).one()

    motivo_row = (
        db.query(Merma.motivo, func.count(Merma.id).label("total"))
        .filter(Merma.empresa_id == empresa_id, Merma.created_at >= primer_dia_mes)
        .group_by(Merma.motivo)
        .order_by(func.count(Merma.id).desc())
        .first()
    )
    motivo_mas_frecuente = motivo_row[0] if motivo_row else None

    return DashboardResponse(
        tasa_bcv=tasa_bcv,
        ventas_hoy=VentasHoyResponse(monto_usd=ventas_usd, monto_ves=ventas_ves),
        alertas_stock_bajo=alertas_stock_bajo,
        alertas_vencimiento=alertas_vencimiento,
        resumen_mermas_mes=ResumenMermasResponse(
            cantidad_total_mermada=Decimal(str(total_mermado)),
            total_registros=total_registros,
            motivo_mas_frecuente=motivo_mas_frecuente
        )
    )

# --- CRM: Post-Venta y Control de Faltantes ---

# Verifica si existe stock activo (> 0) de un producto cuyo nombre coincide con el item solicitado
def _item_disponible(db: Session, empresa_id: int, item: str) -> bool:
    stock = (
        db.query(func.coalesce(func.sum(Lote.cantidad_actual), 0))
        .join(Producto, Producto.id == Lote.producto_id)
        .filter(
            Producto.empresa_id == empresa_id,
            Lote.empresa_id == empresa_id,
            Lote.status == "activo",
            Producto.nombre.ilike(f"%{item}%")
        )
        .scalar()
    )
    return Decimal(str(stock)) > 0

# 17. Registrar Petición de Faltante: el cliente solicita un producto que no está en catálogo/stock
@app.post("/api/v1/crm/faltantes", tags=["CRM"], response_model=PeticionFaltanteResponse)
def crear_peticion_faltante(
    datos: PeticionFaltanteCreate,
    db: Session = Depends(get_db),
    usuario_actual: TokenData = Depends(verificar_rol(ROLES_OPERACION))
):
    empresa_id = usuario_actual.eid
    cliente = db.query(Cliente).filter(Cliente.id == datos.cliente_id, Cliente.empresa_id == empresa_id).first()
    if not cliente:
        raise HTTPException(status_code=404, detail="Cliente no encontrado.")

    peticion = PeticionFaltante(empresa_id=empresa_id, cliente_id=datos.cliente_id, item=datos.item)
    db.add(peticion)
    db.commit()
    db.refresh(peticion)

    return PeticionFaltanteResponse(
        id=peticion.id, cliente_id=peticion.cliente_id, cliente_nombre=cliente.nombre,
        item=peticion.item, status=peticion.status,
        disponible=_item_disponible(db, empresa_id, peticion.item),
        created_at=peticion.created_at
    )

# 18. Listar Peticiones de Faltantes: Libro de Faltantes con disponibilidad de stock calculada en vivo
@app.get("/api/v1/crm/faltantes", tags=["CRM"], response_model=List[PeticionFaltanteResponse])
def listar_peticiones_faltantes(
    skip: int = 0, limit: int = 100,
    db: Session = Depends(get_db),
    usuario_actual: TokenData = Depends(verificar_rol(ROLES_OPERACION))
):
    empresa_id = usuario_actual.eid
    filas = (
        db.query(PeticionFaltante, Cliente.nombre)
        .join(Cliente, Cliente.id == PeticionFaltante.cliente_id)
        .filter(PeticionFaltante.empresa_id == empresa_id)
        .order_by(PeticionFaltante.created_at.desc())
        .offset(skip).limit(limit)
        .all()
    )
    return [
        PeticionFaltanteResponse(
            id=p.id, cliente_id=p.cliente_id, cliente_nombre=nombre,
            item=p.item, status=p.status,
            disponible=_item_disponible(db, empresa_id, p.item),
            created_at=p.created_at
        )
        for p, nombre in filas
    ]

# 19. Logs de Post-Venta: feed de actividad del bot de calidad y ofertas
@app.get("/api/v1/crm/postventa-logs", tags=["CRM"], response_model=List[SeguimientoBotResponse])
def listar_postventa_logs(
    cliente_id: Optional[int] = None,
    status_envio: Optional[str] = None,
    skip: int = 0, limit: int = 100,
    db: Session = Depends(get_db),
    usuario_actual: TokenData = Depends(verificar_rol(ROLES_OPERACION))
):
    empresa_id = usuario_actual.eid
    query = (
        db.query(SeguimientoBot, Cliente.nombre)
        .join(Ticket, Ticket.id == SeguimientoBot.ticket_id)
        .join(Cliente, Cliente.id == Ticket.cliente_id)
        .filter(SeguimientoBot.empresa_id == empresa_id)
    )
    if cliente_id is not None:
        query = query.filter(Ticket.cliente_id == cliente_id)
    if status_envio is not None:
        query = query.filter(SeguimientoBot.status_envio == status_envio)

    filas = (
        query.order_by(SeguimientoBot.created_at.desc())
        .offset(skip).limit(limit)
        .all()
    )
    return [
        SeguimientoBotResponse(
            id=s.id, ticket_id=s.ticket_id, cliente_nombre=nombre,
            tipo_mensaje=s.tipo_mensaje, respuesta_cliente=s.respuesta_cliente,
            status_envio=s.status_envio, created_at=s.created_at
        )
        for s, nombre in filas
    ]

# 19b. Registrar Encuesta de Post-Venta
@app.post("/api/v1/crm/postventa-logs", tags=["CRM"], response_model=SeguimientoBotResponse, status_code=status.HTTP_201_CREATED)
def crear_postventa_log(
    datos: SeguimientoBotCreate,
    db: Session = Depends(get_db),
    usuario_actual: TokenData = Depends(get_current_user)
):
    ticket = db.query(Ticket).filter(Ticket.id == datos.ticket_id, Ticket.empresa_id == usuario_actual.eid).first()
    if not ticket:
        raise HTTPException(status_code=404, detail="Ticket no encontrado o no pertenece a su empresa.")
        
    cliente = db.query(Cliente).filter(Cliente.id == ticket.cliente_id).first()
    cliente_nombre = cliente.nombre if cliente else "Desconocido"

    nuevo_log = SeguimientoBot(
        empresa_id=usuario_actual.eid,
        ticket_id=datos.ticket_id,
        tipo_mensaje=datos.tipo_mensaje,
        respuesta_cliente=datos.respuesta_cliente,
        status_envio=datos.status_envio
    )
    try:
        db.add(nuevo_log)
        db.commit()
        db.refresh(nuevo_log)
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=400, detail=f"Error al registrar la encuesta: {str(e)}")
        
    return SeguimientoBotResponse(
        id=nuevo_log.id,
        ticket_id=nuevo_log.ticket_id,
        cliente_nombre=cliente_nombre,
        tipo_mensaje=nuevo_log.tipo_mensaje,
        respuesta_cliente=nuevo_log.respuesta_cliente,
        status_envio=nuevo_log.status_envio,
        created_at=nuevo_log.created_at
    )

# 19c. Resolver Encuesta de Post-Venta
@app.put("/api/v1/crm/postventa-logs/{log_id}", tags=["CRM"], response_model=SeguimientoBotResponse)
def actualizar_postventa_log(
    log_id: int,
    datos: SeguimientoBotUpdate,
    db: Session = Depends(get_db),
    usuario_actual: TokenData = Depends(verificar_rol(ROLES_OPERACION))
):
    log = db.query(SeguimientoBot).filter(SeguimientoBot.id == log_id, SeguimientoBot.empresa_id == usuario_actual.eid).first()
    if not log:
        raise HTTPException(status_code=404, detail="Registro de postventa no encontrado.")
        
    ticket = db.query(Ticket).filter(Ticket.id == log.ticket_id).first()
    cliente = db.query(Cliente).filter(Cliente.id == ticket.cliente_id).first() if ticket else None
    cliente_nombre = cliente.nombre if cliente else "Desconocido"

    log.status_envio = datos.status_envio
    if datos.respuesta_cliente is not None:
        log.respuesta_cliente = datos.respuesta_cliente
        
    try:
        db.commit()
        db.refresh(log)
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=400, detail=f"Error al actualizar la encuesta: {str(e)}")
        
    return SeguimientoBotResponse(
        id=log.id,
        ticket_id=log.ticket_id,
        cliente_nombre=cliente_nombre,
        tipo_mensaje=log.tipo_mensaje,
        respuesta_cliente=log.respuesta_cliente,
        status_envio=log.status_envio,
        created_at=log.created_at
    )


# 20. Crear Proveedor (Aislamiento Multi-Tenant)
@app.post("/api/v1/proveedores", tags=["Proveedores"], response_model=ProveedorResponse, status_code=status.HTTP_201_CREATED)
def crear_proveedor(
    datos: ProveedorCreate,
    db: Session = Depends(get_db),
    usuario_actual: TokenData = Depends(verificar_rol(ROLES_OPERACION))
):
    duplicado = db.query(Proveedor).filter(
        Proveedor.empresa_id == usuario_actual.eid,
        Proveedor.rif == datos.rif.strip()
    ).first()
    if duplicado:
        raise HTTPException(status_code=400, detail="Ya existe un proveedor con ese RIF en su empresa.")

    nuevo_proveedor = Proveedor(
        empresa_id=usuario_actual.eid,
        rif=datos.rif.strip(),
        nombre=datos.nombre.strip(),
        telefono=datos.telefono.strip() if datos.telefono else None,
        email=datos.email.strip() if datos.email else None,
        direccion=datos.direccion.strip() if datos.direccion else None
    )
    try:
        db.add(nuevo_proveedor)
        db.commit()
        db.refresh(nuevo_proveedor)
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=400, detail=f"Error al registrar el proveedor: {str(e)}")
    return nuevo_proveedor

# 21. Listar Proveedores (Aislamiento Multi-Tenant)
@app.get("/api/v1/proveedores", tags=["Proveedores"], response_model=List[ProveedorResponse])
def listar_proveedores(
    db: Session = Depends(get_db),
    usuario_actual: TokenData = Depends(verificar_rol(ROLES_OPERACION))
):
    return db.query(Proveedor).filter(Proveedor.empresa_id == usuario_actual.eid).all()

# 22. Crear Vehículo (Aislamiento Multi-Tenant)
@app.post("/api/v1/vehiculos", tags=["Vehículos"], response_model=VehiculoResponse, status_code=status.HTTP_201_CREATED)
def crear_vehiculo(
    datos: VehiculoCreate,
    db: Session = Depends(get_db),
    usuario_actual: TokenData = Depends(verificar_rol(ROLES_OPERACION))
):
    duplicado = db.query(Vehiculo).filter(
        Vehiculo.empresa_id == usuario_actual.eid,
        Vehiculo.placa == datos.placa.strip()
    ).first()
    if duplicado:
        raise HTTPException(status_code=400, detail="Ya existe un vehículo con esa placa en su empresa.")

    nuevo_vehiculo = Vehiculo(
        empresa_id=usuario_actual.eid,
        placa=datos.placa.strip(),
        marca=datos.marca.strip(),
        modelo=datos.modelo.strip(),
        tipo=datos.tipo.strip(),
        status=datos.status.strip()
    )
    try:
        db.add(nuevo_vehiculo)
        db.commit()
        db.refresh(nuevo_vehiculo)
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=400, detail=f"Error al registrar el vehículo: {str(e)}")
    return nuevo_vehiculo

# 23. Listar Vehículos (Aislamiento Multi-Tenant)
@app.get("/api/v1/vehiculos", tags=["Vehículos"], response_model=List[VehiculoResponse])
def listar_vehiculos(
    db: Session = Depends(get_db),
    usuario_actual: TokenData = Depends(verificar_rol(ROLES_OPERACION))
):
    return db.query(Vehiculo).filter(Vehiculo.empresa_id == usuario_actual.eid).all()

# 24. Crear Usuario / Empleado (Aislamiento Multi-Tenant, solo Propietarios/Admin)
@app.post("/api/v1/usuarios", tags=["Usuarios"], response_model=UsuarioResponse, status_code=status.HTTP_201_CREATED)
def crear_usuario(
    datos: UsuarioCreate,
    db: Session = Depends(get_db),
    usuario_actual: TokenData = Depends(verificar_rol(ROLES_GESTION))
):
    duplicado = db.query(Usuario).filter(Usuario.email == datos.email.strip()).first()
    if duplicado:
        raise HTTPException(status_code=400, detail="El correo electrónico ya está en uso.")

    nuevo_usuario = Usuario(
        empresa_id=usuario_actual.eid,
        nombre=datos.nombre.strip(),
        email=datos.email.strip(),
        password_hash=generar_hash_password(datos.password[:72]),
        rol=datos.rol.strip().lower(),
        status=datos.status
    )
    try:
        db.add(nuevo_usuario)
        db.commit()
        db.refresh(nuevo_usuario)
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=400, detail=f"Error al registrar el usuario: {str(e)}")
    return nuevo_usuario

# 25. Listar Usuarios / Empleados (Aislamiento Multi-Tenant, solo Propietarios/Admin)
@app.get("/api/v1/usuarios", tags=["Usuarios"], response_model=List[UsuarioResponse])
def listar_usuarios(
    db: Session = Depends(get_db),
    usuario_actual: TokenData = Depends(verificar_rol(ROLES_GESTION))
):
    return db.query(Usuario).filter(Usuario.empresa_id == usuario_actual.eid).all()

# 26. Analizar Foto de Producto con IA (Simulador Inteligente de Visión Computacional)
@app.post("/api/v1/productos/analizar-foto", tags=["Productos"])
async def analizar_foto_producto(
    file: UploadFile = File(...),
    usuario_actual: TokenData = Depends(get_current_user)
):
    nombre_archivo = file.filename.lower()
    
    # Simulación inteligente según palabras clave del archivo
    if "harina" in nombre_archivo or "pan" in nombre_archivo:
        return {
            "codigo_interno": "P001",
            "codigo_barras": "7591001000112",
            "nombre": "Harina de Maíz Blanco Precocida",
            "marca": "P.A.N.",
            "linea": "Víveres",
            "clase_o_tipo": "Harinas",
            "tipo_envase": "Empaque",
            "peso": 1.000,
            "ubicacion": "Pasillo 1 - Anaquel A",
            "tipo_venta": "unidad",
            "refrigerado": False,
            "perecedero": True,
            "fecha_elaboracion": str(datetime.date.today() - datetime.timedelta(days=15)),
            "fecha_vencimiento": str(datetime.date.today() + datetime.timedelta(days=180)),
            "costo_usd": 1.10,
            "precio_1_detalle": 1.35,
            "precio_2_mayorista": 1.25,
            "precio_3_especial": 1.20,
            "aplica_iva": False,
            "foto_url": "https://images.unsplash.com/photo-1590080875515-8a3a8dc5735e?auto=format&fit=crop&w=400&q=80"
        }
    elif "pepsi" in nombre_archivo or "refresco" in nombre_archivo or "cola" in nombre_archivo:
        return {
            "codigo_interno": "PEPSI-1.5L",
            "codigo_barras": "7591001001234",
            "nombre": "Refresco Pepsi Cola",
            "marca": "Pepsi",
            "linea": "Bebidas",
            "clase_o_tipo": "Refrescos",
            "tipo_envase": "Botella",
            "peso": 1.500,
            "ubicacion": "Nevera Bebidas 2",
            "tipo_venta": "unidad",
            "refrigerado": True,
            "perecedero": True,
            "fecha_elaboracion": str(datetime.date.today() - datetime.timedelta(days=30)),
            "fecha_vencimiento": str(datetime.date.today() + datetime.timedelta(days=360)),
            "costo_usd": 1.50,
            "precio_1_detalle": 1.95,
            "precio_2_mayorista": 1.80,
            "precio_3_especial": 1.70,
            "aplica_iva": True,
            "foto_url": "https://images.unsplash.com/photo-1629203851122-3726ecdf080e?auto=format&fit=crop&w=400&q=80"
        }
    elif "remedio" in nombre_archivo or "medicina" in nombre_archivo or "pastilla" in nombre_archivo or "jarabe" in nombre_archivo:
        return {
            "codigo_interno": "MED-IBU400",
            "codigo_barras": "7592002003456",
            "nombre": "Ibuprofeno 400mg",
            "marca": "Genfar",
            "linea": "Farmacia",
            "clase_o_tipo": "Analgésicos",
            "tipo_envase": "Blíster",
            "peso": 0.050,
            "ubicacion": "Vitrina Principal A",
            "tipo_venta": "unidad",
            "refrigerado": False,
            "perecedero": True,
            "fecha_elaboracion": str(datetime.date.today() - datetime.timedelta(days=90)),
            "fecha_vencimiento": str(datetime.date.today() + datetime.timedelta(days=720)),
            "costo_usd": 2.20,
            "precio_1_detalle": 3.50,
            "precio_2_mayorista": 3.00,
            "precio_3_especial": 2.80,
            "aplica_iva": False,
            "foto_url": "https://images.unsplash.com/photo-1584017911766-d451b3d0e843?auto=format&fit=crop&w=400&q=80"
        }
    else:
        return {
            "codigo_interno": f"GEN-{datetime.date.today().strftime('%m%d')}",
            "codigo_barras": "7593003004567",
            "nombre": "Galletas de Soda Crackers",
            "marca": "Mary",
            "linea": "Víveres",
            "clase_o_tipo": "Galletas",
            "tipo_envase": "Empaque",
            "peso": 0.350,
            "ubicacion": "Pasillo 3 - Anaquel B",
            "tipo_venta": "unidad",
            "refrigerado": False,
            "perecedero": True,
            "fecha_elaboracion": str(datetime.date.today() - datetime.timedelta(days=20)),
            "fecha_vencimiento": str(datetime.date.today() + datetime.timedelta(days=240)),
            "costo_usd": 0.85,
            "precio_1_detalle": 1.20,
            "precio_2_mayorista": 1.10,
            "precio_3_especial": 1.05,
            "aplica_iva": True,
            "foto_url": "https://images.unsplash.com/photo-1549465220-1a8b9238cd48?auto=format&fit=crop&w=400&q=80"
        }

# 27. Registrar Pesaje (Balanza Digital - Ticket Pendiente)
@app.post("/api/v1/tickets/pesaje", tags=["Ventas"], response_model=TicketResponse, status_code=status.HTTP_201_CREATED)
def crear_ticket_pesaje(
    datos: TicketPesajeCreate,
    db: Session = Depends(get_db),
    usuario_actual: TokenData = Depends(get_current_user)
):
    cliente = db.query(Cliente).filter(Cliente.id == datos.cliente_id, Cliente.empresa_id == usuario_actual.eid).first()
    if not cliente:
        raise HTTPException(status_code=404, detail="Cliente no encontrado.")

    producto = db.query(Producto).filter(Producto.id == datos.producto_id, Producto.empresa_id == usuario_actual.eid).first()
    if not producto:
        raise HTTPException(status_code=404, detail="Producto no encontrado.")

    # Calcular monto USD
    monto_usd = (datos.peso * producto.precio_1_detalle).quantize(Decimal("0.01"))

    tasa = db.query(TasaCambio).filter(TasaCambio.empresa_id == usuario_actual.eid).first()
    tasa_bcv = tasa.valor_bcv if tasa else Decimal("0")
    monto_ves = (monto_usd * tasa_bcv).quantize(Decimal("0.01"))

    nuevo_ticket = Ticket(
        empresa_id=usuario_actual.eid,
        usuario_id=usuario_actual.usuario_id,
        producto_id=datos.producto_id,
        cliente_id=datos.cliente_id,
        peso=datos.peso,
        monto_usd=monto_usd,
        status="pendiente"
    )
    try:
        db.add(nuevo_ticket)
        db.commit()
        db.refresh(nuevo_ticket)
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=400, detail=f"Error al registrar el pesaje: {str(e)}")

    return TicketResponse(
        id=nuevo_ticket.id,
        empresa_id=nuevo_ticket.empresa_id,
        usuario_id=nuevo_ticket.usuario_id,
        producto_id=nuevo_ticket.producto_id,
        cliente_id=nuevo_ticket.cliente_id,
        peso=nuevo_ticket.peso,
        monto_usd=nuevo_ticket.monto_usd,
        monto_ves=monto_ves,
        status=nuevo_ticket.status,
        created_at=nuevo_ticket.created_at,
        direccion_entrega=nuevo_ticket.direccion_entrega,
        repartidor_id=nuevo_ticket.repartidor_id,
        x=nuevo_ticket.coord_x,
        y=nuevo_ticket.coord_y,
        cliente=cliente.nombre if cliente else "Desconocido",
        direccion=nuevo_ticket.direccion_entrega
    )

# 28. Procesar Pago y Liquidación de Tickets de Balanza (Caja / POS)
# 28. Cancelar Ticket de Balanza Pendiente (Caja / POS)
@app.put("/api/v1/tickets/{ticket_id}/cancelar", tags=["Ventas"])
def cancelar_ticket(
    ticket_id: int,
    db: Session = Depends(get_db),
    usuario_actual: TokenData = Depends(verificar_rol(ROLES_OPERACION))
):
    ticket = db.query(Ticket).filter(
        Ticket.id == ticket_id,
        Ticket.empresa_id == usuario_actual.eid,
        Ticket.status == "pendiente"
    ).first()
    if not ticket:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Ticket no encontrado o no está en estatus pendiente."
        )
    ticket.status = "cancelado"
    db.commit()
    return {"mensaje": "Ticket cancelado exitosamente.", "ticket_id": ticket_id}

# 29. Procesar Pago y Liquidación de Tickets de Balanza (Caja / POS)
@app.post("/api/v1/tickets/procesar-pago", tags=["Ventas"])
def procesar_pago_tickets(
    datos: ProcesarPagoTickets,
    db: Session = Depends(get_db),
    usuario_actual: TokenData = Depends(verificar_rol(ROLES_OPERACION))
):
    tickets_procesados = []
    try:
        mod_map = {}
        if datos.modificaciones:
            for mod in datos.modificaciones:
                mod_map[mod.ticket_id] = mod.peso

        for tid in datos.ticket_ids:
            ticket = db.query(Ticket).filter(
                Ticket.id == tid,
                Ticket.empresa_id == usuario_actual.eid,
                Ticket.status == "pendiente"
            ).first()
            if not ticket:
                continue

            # Aplicar modificación de peso si existe
            if ticket.id in mod_map:
                nuevo_peso = mod_map[ticket.id]
                producto = db.query(Producto).filter(Producto.id == ticket.producto_id).first()
                if producto:
                    ticket.peso = nuevo_peso
                    ticket.monto_usd = (nuevo_peso * producto.precio_1_detalle).quantize(Decimal("0.01"))

            # Descontar stock usando FIFO/FEFO
            lotes = db.query(Lote).filter(
                Lote.empresa_id == usuario_actual.eid,
                Lote.producto_id == ticket.producto_id,
                Lote.status == "activo",
                Lote.cantidad_actual > 0
            ).order_by(Lote.fecha_vencimiento.asc(), Lote.fecha_ingreso.asc()).all()

            stock_disponible = sum((lote.cantidad_actual for lote in lotes), Decimal("0"))
            if stock_disponible < ticket.peso:
                producto = db.query(Producto).filter(Producto.id == ticket.producto_id).first()
                nombre_p = producto.nombre if producto else f"ID {ticket.producto_id}"
                raise HTTPException(
                    status_code=400,
                    detail=f"Stock insuficiente en lotes para '{nombre_p}'. Disponible: {stock_disponible}, solicitado: {ticket.peso}"
                )

            restante = ticket.peso
            for lote in lotes:
                if restante <= 0:
                    break
                descuento = min(lote.cantidad_actual, restante)
                lote.cantidad_actual -= descuento
                restante -= descuento
                if lote.cantidad_actual == 0:
                    lote.status = "agotado"

            ticket.status = "procesado"
            tickets_procesados.append(ticket)

        db.commit()
    except HTTPException:
        db.rollback()
        raise
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=400, detail=f"Error al procesar el cobro: {str(e)}")

    return {"mensaje": "Cobro de balanza finalizado.", "tickets_actualizados": len(tickets_procesados)}


# --- Utilidades y Endpoints de Delivery Exprés y Compras ---

def lat_lng_to_svg(lat: float, lng: float) -> tuple[float, float]:
    min_lat, max_lat = 8.5900, 8.6600
    min_lng, max_lng = -70.2400, -70.1800
    y = 340.0 - ((lat - min_lat) / (max_lat - min_lat)) * 320.0
    x = 20.0 + ((lng - min_lng) / (max_lng - min_lng)) * 460.0
    return round(x, 1), round(y, 1)

@app.post("/api/v1/pedidos", tags=["Delivery"], response_model=PedidoDeliveryResponse, status_code=status.HTTP_201_CREATED)
def crear_pedido_delivery(
    datos: PedidoDeliveryCreate,
    db: Session = Depends(get_db),
    usuario_actual: TokenData = Depends(verificar_rol(ROLES_OPERACION))
):
    x, y = lat_lng_to_svg(datos.destino_lat, datos.destino_lng)
    nuevo_pedido = PedidoDelivery(
        empresa_id=usuario_actual.eid,
        cliente_nombre=datos.cliente_nombre,
        cliente_telefono=datos.cliente_telefono,
        cliente_direccion=datos.cliente_direccion,
        vehiculo_id=datos.vehiculo_id,
        chofer_cedula=datos.chofer_cedula,
        origen=datos.origen,
        origen_lat=datos.origen_lat,
        origen_lng=datos.origen_lng,
        destino=datos.destino,
        destino_lat=datos.destino_lat,
        destino_lng=datos.destino_lng,
        distancia_km=datos.distancia_km,
        eta_min=datos.eta_min,
        estado=datos.estado,
        metodo_pago=datos.metodo_pago,
        monto_total=datos.monto_total,
        notas=datos.notas,
        coord_x=x,
        coord_y=y
    )
    try:
        db.add(nuevo_pedido)
        db.commit()
        db.refresh(nuevo_pedido)
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=400, detail=f"Error al crear el pedido de delivery: {str(e)}")
    return nuevo_pedido

@app.get("/api/v1/pedidos", tags=["Delivery"], response_model=List[PedidoDeliveryResponse])
def listar_pedidos_delivery(
    estado: Optional[str] = None,
    db: Session = Depends(get_db),
    usuario_actual: TokenData = Depends(verificar_rol(ROLES_OPERACION))
):
    query = db.query(PedidoDelivery).filter(PedidoDelivery.empresa_id == usuario_actual.eid)
    if estado:
        query = query.filter(PedidoDelivery.estado == estado)
    return query.all()

@app.post("/api/v1/pedidos/guardar-auditado", tags=["Compras"], response_model=OrdenCompraResponse, status_code=status.HTTP_201_CREATED)
def crear_orden_compra(
    datos: OrdenCompraCreate,
    db: Session = Depends(get_db),
    usuario_actual: TokenData = Depends(verificar_rol(ROLES_GESTION))
):
    if not datos.items:
        raise HTTPException(status_code=400, detail="La orden de compra debe incluir al menos un producto.")
    total_usd = sum((item.cantidad * item.costo for item in datos.items), 0.0)
    nueva_orden = OrdenCompra(
        empresa_id=usuario_actual.eid,
        proveedor=datos.proveedor,
        items_count=len(datos.items),
        total_usd=total_usd,
        origen="Borrador Auditado",
        estatus="Pendiente"
    )
    try:
        db.add(nueva_orden)
        db.flush()
        for item in datos.items:
            db.add(OrdenCompraItem(
                orden_id=nueva_orden.id,
                producto_nombre=item.nombre,
                cantidad=item.cantidad,
                costo=item.costo
            ))
        db.commit()
        db.refresh(nueva_orden)
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=400, detail=f"Error al registrar la orden de compra: {str(e)}")
    return nueva_orden

@app.get("/api/v1/pedidos/ordenes", tags=["Compras"], response_model=List[OrdenCompraResponse])
def listar_ordenes_compra(
    db: Session = Depends(get_db),
    usuario_actual: TokenData = Depends(verificar_rol(ROLES_GESTION))
):
    return db.query(OrdenCompra).filter(OrdenCompra.empresa_id == usuario_actual.eid).order_by(OrdenCompra.created_at.desc()).all()


# --- Servir el Frontend ya compilado (npm run build -> frontend/dist) ---
# Se registra al final para que no choque con ninguna ruta /api/v1/... de arriba.
# El catch-all devuelve cualquier archivo estático existente (assets, favicon, etc.)
# y si no existe, cae en index.html para que React Router resuelva la navegación
# del lado del cliente (ej. refrescar en /dashboard).
_frontend_dist = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "frontend", "dist")
if os.path.isdir(_frontend_dist):
    @app.get("/{full_path:path}", include_in_schema=False)
    def servir_frontend(full_path: str):
        candidato = os.path.join(_frontend_dist, full_path)
        if full_path and os.path.isfile(candidato):
            return FileResponse(candidato)
        return FileResponse(os.path.join(_frontend_dist, "index.html"))
