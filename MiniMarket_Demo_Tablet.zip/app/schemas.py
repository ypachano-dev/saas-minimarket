import datetime
from decimal import Decimal
from pydantic import BaseModel, ConfigDict, Field
from typing import List, Optional

# Este es el molde de lo que el navegador debe enviar para registrar un negocio
class RegistroEmpresaAdmin(BaseModel):
    # Datos del Minimarket / Empresa
    nombre_empresa: str
    rif_or_cedula: str
    telefono: Optional[str] = None
    direccion: Optional[str] = None
    
    # Datos del Dueño / Administrador
    nombre_admin: str
    username_admin: str
    email_admin: str
    password_admin: str

# Molde de entrada para el inicio de sesión
class LoginRequest(BaseModel):
    email: str
    password: str

# Molde de salida del Token JWT
class Token(BaseModel):
    access_token: str
    token_type: str = "bearer"

# Datos extraídos del payload del Token JWT (usuario autenticado)
# Nota: 'eid' es el alias compacto de 'empresa_id' dentro del JWT para reducir el tamaño del token
class TokenData(BaseModel):
    usuario_id: int
    eid: int
    rol: str

# Campos comunes para crear/leer un Cliente (sin empresa_id, inyectado por el backend)
class ClienteBase(BaseModel):
    cedula: str
    nombre: str
    telefono: Optional[str] = None
    email: Optional[str] = None
    instagram: Optional[str] = None
    telegram: Optional[str] = None

# Molde de entrada para registrar un Cliente
class ClienteCreate(ClienteBase):
    pass

# Molde de entrada para editar un Cliente (todos los campos opcionales)
class ClienteUpdate(BaseModel):
    cedula: Optional[str] = None
    nombre: Optional[str] = None
    telefono: Optional[str] = None
    email: Optional[str] = None
    instagram: Optional[str] = None
    telegram: Optional[str] = None

# Molde de salida con los datos completos del Cliente
class ClienteResponse(ClienteBase):
    model_config = ConfigDict(from_attributes=True)

    id: int
    empresa_id: int
    created_at: datetime.datetime

# Campos comunes para crear/leer un Producto (sin empresa_id, inyectado por el backend)
class ProductoBase(BaseModel):
    codigo_interno: str
    codigo_barras: Optional[str] = None
    nombre: str
    caracteristicas: Optional[str] = None
    marca: Optional[str] = None
    linea: Optional[str] = None
    clase_o_tipo: Optional[str] = None
    tipo_envase: Optional[str] = None
    ubicacion: Optional[str] = None
    refrigerado: bool = False
    perecedero: bool = False
    fecha_elaboracion: Optional[datetime.date] = None
    fecha_vencimiento: Optional[datetime.date] = None
    fecha_ingreso_stock: Optional[datetime.date] = None
    stock_minimo: Decimal = Decimal("0.000")
    costo_usd: Decimal = Decimal("0.0000")
    precio_1_detalle: Decimal = Decimal("0.0000")
    precio_2_mayorista: Decimal = Decimal("0.0000")
    precio_3_especial: Decimal = Decimal("0.0000")
    aplica_iva: bool = True

# Molde de entrada para registrar un Producto
class ProductoCreate(ProductoBase):
    pass

# Molde de salida con los datos completos del Producto
class ProductoResponse(ProductoBase):
    model_config = ConfigDict(from_attributes=True)

    id: int
    empresa_id: int
    status: bool
    created_at: datetime.datetime
    stock_total: float = 0.0

# Molde de entrada para registrar la entrada de un Lote (sin empresa_id, inyectado por el backend)
class LoteCreate(BaseModel):
    producto_id: int
    codigo_lote: str
    cantidad_inicial: Decimal
    fecha_ingreso: Optional[datetime.date] = None  # Si no se envía, se usa la fecha actual
    fecha_vencimiento: datetime.date

# Molde de salida con los datos completos del Lote
class LoteResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int
    empresa_id: int
    producto_id: int
    codigo_lote: str
    cantidad_inicial: Decimal
    cantidad_actual: Decimal
    fecha_ingreso: datetime.date
    fecha_vencimiento: datetime.date
    status: str
    created_at: datetime.datetime

# Molde de entrada para registrar una Merma (sin empresa_id ni usuario_id, inyectados por el backend)
class MermaCreate(BaseModel):
    lote_id: int
    cantidad: Decimal
    motivo: str
    observaciones: Optional[str] = None

# Molde de salida con los datos completos de la Merma
class MermaResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int
    empresa_id: int
    usuario_id: int
    producto_id: int
    lote_id: Optional[int] = None
    cantidad: Decimal
    motivo: str
    observaciones: Optional[str] = None
    created_at: datetime.datetime

# Un producto/línea dentro de la venta (peso o cantidad despachada)
class TicketItemCreate(BaseModel):
    producto_id: int
    peso: Decimal

# Molde de entrada para registrar una venta (sin empresa_id ni usuario_id, inyectados por el backend)
class TicketCreate(BaseModel):
    cliente_id: int
    items: List[TicketItemCreate]

# Molde de salida con los datos completos de un Ticket (una línea de la venta)
# monto_ves se calcula dinámicamente (no se almacena) a partir de la tasa BCV vigente
class TicketResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True, populate_by_name=True)

    id: int
    empresa_id: int
    usuario_id: int
    producto_id: int
    cliente_id: int
    peso: Decimal
    monto_usd: Decimal
    monto_ves: Decimal
    status: str
    created_at: datetime.datetime
    direccion_entrega: Optional[str] = None
    repartidor_id: Optional[int] = None
    x: float = Field(default=250.0, validation_alias="coord_x")
    y: float = Field(default=180.0, validation_alias="coord_y")
    cliente: Optional[str] = None
    direccion: Optional[str] = None

# Resumen devuelto al cerrar la venta: cada línea generada y los totales en ambas monedas
class VentaResponse(BaseModel):
    tickets: List[TicketResponse]
    total_usd: Decimal
    total_ves: Decimal
    tasa_bcv: Decimal

# Molde de entrada para actualizar la tasa BCV de la empresa
class TasaCambioUpdate(BaseModel):
    valor_bcv: Decimal

# Molde de salida con la tasa BCV vigente de la empresa
class TasaCambioResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int
    empresa_id: int
    valor_bcv: Decimal
    fecha_actualizacion: datetime.datetime

# --- Módulo de Analítica y Reportes (Dashboard) ---

class StockBajoItem(BaseModel):
    producto_id: int
    codigo_interno: str
    nombre: str
    stock_total: Decimal

class LoteCriticoItem(BaseModel):
    lote_id: int
    producto_id: int
    producto_nombre: str
    codigo_lote: str
    cantidad_actual: Decimal
    fecha_vencimiento: datetime.date
    dias_restantes: int

class VentasHoyResponse(BaseModel):
    monto_usd: Decimal
    monto_ves: Decimal

class ResumenMermasResponse(BaseModel):
    cantidad_total_mermada: Decimal
    total_registros: int
    motivo_mas_frecuente: Optional[str] = None

class DashboardResponse(BaseModel):
    tasa_bcv: Decimal
    ventas_hoy: VentasHoyResponse
    alertas_stock_bajo: List[StockBajoItem]
    alertas_vencimiento: List[LoteCriticoItem]
    resumen_mermas_mes: ResumenMermasResponse

# --- CRM: Post-Venta y Control de Faltantes ---
class PeticionFaltanteCreate(BaseModel):
    cliente_id: int
    item: str

class PeticionFaltanteResponse(BaseModel):
    id: int
    cliente_id: int
    cliente_nombre: str
    item: str
    status: str
    disponible: bool
    created_at: datetime.datetime

class SeguimientoBotResponse(BaseModel):
    id: int
    ticket_id: int
    cliente_nombre: str
    tipo_mensaje: str
    respuesta_cliente: Optional[str] = None
    status_envio: str
    created_at: datetime.datetime

class SeguimientoBotCreate(BaseModel):
    ticket_id: int
    tipo_mensaje: str
    respuesta_cliente: Optional[str] = None
    status_envio: str = "pendiente"

class SeguimientoBotUpdate(BaseModel):
    status_envio: str
    respuesta_cliente: Optional[str] = None

# --- Nuevos Esquemas para Ingreso de Datos ---

class ProveedorCreate(BaseModel):
    rif: str
    nombre: str
    telefono: Optional[str] = None
    email: Optional[str] = None
    direccion: Optional[str] = None

class ProveedorResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    empresa_id: int
    rif: str
    nombre: str
    telefono: Optional[str] = None
    email: Optional[str] = None
    direccion: Optional[str] = None
    created_at: datetime.datetime

class VehiculoCreate(BaseModel):
    placa: str
    marca: str
    modelo: str
    tipo: str # Moto, Carro, Camión
    status: str = "Operativo" # Operativo, Mantenimiento, Inactivo

class VehiculoResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    empresa_id: int
    placa: str
    marca: str
    modelo: str
    tipo: str
    status: str
    created_at: datetime.datetime

class UsuarioCreate(BaseModel):
    nombre: str
    email: str
    password: str
    rol: str
    status: bool = True

class UsuarioResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    empresa_id: int
    nombre: str
    email: str
    rol: str
    status: bool
    created_at: datetime.datetime

# --- Esquemas de Pesaje e Integración POS ---

class TicketPesajeCreate(BaseModel):
    cliente_id: int
    producto_id: int
    peso: Decimal

class TicketModification(BaseModel):
    ticket_id: int
    peso: Decimal

class ProcesarPagoTickets(BaseModel):
    ticket_ids: List[int]
    modificaciones: Optional[List[TicketModification]] = None

# --- Esquemas para Delivery Exprés (PedidoDelivery) ---
class PedidoDeliveryCreate(BaseModel):
    cliente_nombre: str
    cliente_telefono: str
    cliente_direccion: Optional[str] = None
    vehiculo_id: Optional[int] = None
    chofer_cedula: str
    origen: str
    origen_lat: float
    origen_lng: float
    destino: str
    destino_lat: float
    destino_lng: float
    distancia_km: Optional[float] = None
    eta_min: Optional[int] = None
    estado: str = "CREADO"
    metodo_pago: str
    monto_total: float
    notas: Optional[str] = None

class PedidoDeliveryResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    empresa_id: int
    cliente_nombre: str
    cliente_telefono: str
    cliente_direccion: Optional[str] = None
    vehiculo_id: Optional[int] = None
    chofer_cedula: str
    origen: str
    origen_lat: float
    origen_lng: float
    destino: str
    destino_lat: float
    destino_lng: float
    distancia_km: Optional[float] = None
    eta_min: Optional[int] = None
    estado: str
    metodo_pago: str
    monto_total: float
    notas: Optional[str] = None
    coord_x: float
    coord_y: float
    created_at: datetime.datetime

# --- Esquemas para Pedidos y Compras (OrdenCompra) ---
class OrdenCompraItemCreate(BaseModel):
    nombre: str
    cantidad: float
    costo: float

class OrdenCompraItemResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    producto_nombre: str
    cantidad: float
    costo: float

class OrdenCompraCreate(BaseModel):
    proveedor: str
    items: List[OrdenCompraItemCreate]

class OrdenCompraResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    empresa_id: int
    proveedor: str
    items_count: int
    total_usd: float
    origen: str
    estatus: str
    created_at: datetime.datetime
    items: List[OrdenCompraItemResponse]