from pydantic_settings import BaseSettings, SettingsConfigDict

class Settings(BaseSettings):
    # Variables de entorno con valores por defecto para desarrollo local
    PROJECT_NAME: str = "Orquestador ERP/CRM SaaS"
    API_V1_STR: str = "/api/v1"
    
    # Configuración de Seguridad (Llave secreta para JWT tokens)
    SECRET_KEY: str = "SUPER_SECRET_KEY_PRODUCCION_MINIMARKET_2026"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 60 * 24 * 8  # 8 Días
    
    # Conexión Base de Datos - ¡Cambiado a SQLite automático para evitar XAMPP!
    DATABASE_URL: str = "sqlite:///./saas_minimarket.db"

    # Permite cargar las variables desde un archivo .env si existe
    model_config = SettingsConfigDict(case_sensitive=True, env_file=".env")

settings = Settings()